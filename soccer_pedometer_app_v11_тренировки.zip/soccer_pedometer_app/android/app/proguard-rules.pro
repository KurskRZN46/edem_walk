# Правила для R8 (сжатие релизной сборки).
# Задача: не дать оптимизатору выкинуть классы Flutter-движка
# и плагинов, которые вызываются через MethodChannel (рефлексия).

# Flutter-движок
-keep class io.flutter.** { *; }
-keep class io.flutter.plugins.** { *; }
-dontwarn io.flutter.embedding.**

# Стандартные плагины, используемые в проекте
-keep class dev.fluttercommunity.plus.share.** { *; }
-keep class xyz.luan.audioplayers.** { *; }
-keep class io.flutter.plugins.urllauncher.** { *; }
-keep class io.flutter.plugins.sharedpreferences.** { *; }
-keep class com.baseflow.permissionhandler.** { *; }

# Kotlin
-keep class kotlin.** { *; }
-dontwarn kotlin.**
